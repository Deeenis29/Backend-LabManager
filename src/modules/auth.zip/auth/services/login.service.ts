import bcrypt from "bcrypt";
import * as repo from "@modules/auth/repo/auth.repo";
import { AuditAction } from "@prisma/client";
import { LoginDto } from "@modules/auth/dto/login.dto";
import { signAccessToken, signRefreshToken } from "@modules/auth/utils/jwt";
import { hashToken } from "@modules/auth/utils/crypto";

/**
 * 📌 Login de usuario
 *
 * Flujo implementado:
 * 1. Verifica si el usuario existe.
 * 2. Verifica si la cuenta está bloqueada por intentos fallidos.
 * 3. Valida la contraseña contra el hash almacenado.
 * 4. Maneja intentos fallidos:
 *    - Incrementa `loginAttempts`.
 *    - Si llega a 5 → bloquea la cuenta por 15 minutos (`lockedUntil`).
 * 5. Si es exitoso:
 *    - Resetea los intentos fallidos.
 *    - Registra el login en auditoría.
 *    - Genera tokens (access y refresh).
 *    - Guarda el refresh token en DB (con hash, IP y user-agent).
 *
 * @param input credenciales { email, password }
 * @param ip dirección IP del cliente (para auditoría)
 * @param userAgent información del navegador/dispositivo (para auditoría)
 * @throws Error si credenciales son inválidas o cuenta está bloqueada
 * @returns datos del usuario y los tokens JWT
 */
export const login = async (input: LoginDto, ip?: string, userAgent?: string) => {
  const user = await repo.findByEmail(input.email);
  if (!user) {
    // 🔒 Log de intento fallido sin revelar si existe el usuario
    await repo.addAuditLog(
      null,
      AuditAction.LOGIN_FAILED,
      ip,
      "Invalid email",
      "User",
      null,
      userAgent
    );
    throw new Error("Invalid credentials");
  }

  // ⛔ Verificar bloqueo temporal
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    throw new Error("Account temporarily locked due to too many failed attempts");
  }

  // 🔑 Verificar que tenga hash de contraseña
  if (!user.passwordHash) {
    await repo.addAuditLog(
      user.id,
      AuditAction.LOGIN_FAILED,
      ip,
      "Missing password hash",
      "User",
      user.id,
      userAgent
    );
    throw new Error("Invalid credentials");
  }

  // 🔑 Validar contraseña
  const valid = await bcrypt.compare(input.password, user.passwordHash);
  if (!valid) {
    const attempts = (user.loginAttempts ?? 0) + 1;

    if (attempts >= 5) {
      // 🚫 Bloqueo por 15 minutos
      await repo.updateUser(user.id, {
        loginAttempts: attempts,
        lockedUntil: new Date(Date.now() + 15 * 60 * 1000),
      });

      await repo.addAuditLog(
        user.id,
        AuditAction.LOGIN_FAILED,
        ip,
        "Account locked due to failed attempts",
        "User",
        user.id,
        userAgent
      );
      throw new Error("Account locked due to too many failed attempts");
    }

    // Actualizar intentos fallidos
    await repo.updateUser(user.id, { loginAttempts: attempts });
    await repo.addAuditLog(
      user.id,
      AuditAction.LOGIN_FAILED,
      ip,
      "Invalid password",
      "User",
      user.id,
      userAgent
    );
    throw new Error("Invalid credentials");
  }

  // ✅ Login exitoso → resetear intentos
  await repo.updateUser(user.id, {
    loginAttempts: 0,
    lockedUntil: null,
    lastLoginAt: new Date(),
  });

  await repo.addAuditLog(
    user.id,
    AuditAction.LOGIN,
    ip,
    "Successful login",
    "User",
    user.id,
    userAgent
  );

  // 🔑 Generar tokens
  const payload = { id: user.id, role: user.role };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);

  // Guardar refresh token en DB
  await repo.saveRefreshToken({
    tokenHash: hashToken(refreshToken),
    userId: user.id,
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    ipAddress: ip ?? null,
    userAgent: userAgent ?? null,
  });

  return {
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      documentType: user.documentType,
      documentNumber: user.documentNumber,
    },
    tokens: {
      accessToken,
      refreshToken,
    },
  };
};
